import React, { useState } from 'react';
import ResumeTemplate from "./components/ResumeTemplate";
import "./App.css";

const App = () => {
  const [resumeData, setResumeData] = useState({
    name: 'Aditya Tiwary',
    role: 'Experienced Business Analyst | Supply Chain Optimization | Data Analytics',
    phone: '+44 20 7123 4567',
    email: '',
    linkedin: 'linkedin.com',
    location: 'Birmingham',
    summary: 'With over 9 years of experience in business analysis, supply chain management, and logistics, I have a proven record of reducing costs while enhancing efficiency and customer satisfaction. My expertise includes running advanced business models, financial reporting, and streamlining processes to refine supply chain operations. I am eager to contribute to your commitment to sustainability and the journey to net zero.',
    experience: [
      {
        company: 'Unilever',
        location: 'London, UK',
        title: 'Supply Chain Analyst',
        startDate: '01/2019',
        endDate: '12/2022',
        achievements: [
          'Led a cross-functional team to streamline logistics processes, reducing overall supply chain costs by 15% within a 12-month period.',
          'Optimized inventory levels through improved forecasting accuracy, resulting in a 20% reduction in working capital requirements.',
          'Managed supplier performance and initiated strategic partnerships which enhanced raw material availability by 25%.',
          'Developed robust business models in Excel, simulating various supply scenarios to improve decision-making efficiencies.',
          'Implemented an AIMMS-based planning solution that improved logistics scheduling, enhancing customer satisfaction rates by 30%.',
          'Contributed to a company-wide sustainability initiative aimed at reducing environmental impact, in line with the journey to net-zero emissions.'
        ]
      },
      {
        company: 'GlaxoSmithKline',
        location: 'Brentford, UK',
        title: 'Logistics Coordinator',
        startDate: '06/2016',
        endDate: '12/2018',
        achievements: [
          'Coordinated shipping activities for pharmaceutical products, achieving a 99% on-time delivery record over two years.',
          'Reduced freight costs by 10% through the negotiation of more favorable terms with logistics providers.',
          'Managed a team responsible for ensuring compliance with international logistics and shipping regulations.',
          'Collaborated with manufacturing teams to align production schedules with customer demand, ensuring optimal resource allocation.'
        ]
      }
    ],
    education: [
      {
        school: 'University of Warwick',
        location: 'Coventry, UK',
        degree: 'MSc Supply Chain and Logistics Management',
        startDate: '01/2011',
        endDate: '01/2012'
      },
      {
        school: 'University of Leeds',
        location: 'Leeds, UK',
        degree: 'BSc Economics and Management',
        startDate: '01/2008',
        endDate: '01/2011'
      }
    ],
    achievements: [
      {
        title: 'Team Lead for Sustainability Project',
        description: 'Spearheaded a cross-functional team initiative that targeted a 15% carbon footprint reduction.'
      },
      {
        title: 'Award for Logistics Excellence',
        description: 'Received an internal accolade for outstanding work in logistics coordination'
      },
      {
        title: 'Negotiation Success',
        description: 'Renegotiated freight contracts, cutting transportation costs by 10%'
      }
    ],
    skills: [
      'Supply Chain Management',
      'Logistics Planning',
      'Business Process Optimization',
      'Data Analysis',
      'Financial Reporting',
      'Microsoft Office'
    ],
    courses: [
      {
        title: 'Advanced Excel for Productivity',
        description: 'Certification program by Corporate Finance Institute, sharpening my data analysis and modeling skills for robust business decision-making.'
      },
      {
        title: 'SAP Supply Chain Management',
        description: 'Focused training on supply chain processes via SAP SCM provided by the SAP Training and Certification Shop.'
      }
    ]
  });

  const handleInputChange = (section, field, value, index = null) => {
    if (index !== null) {
      const updatedSection = [...resumeData[section]];
      updatedSection[index][field] = value;
      setResumeData({ ...resumeData, [section]: updatedSection });
    } else {
      setResumeData({ ...resumeData, [field]: value });
    }
  };

  return (
    <div className="resume-container">
      <div className="header">
        <h1 contentEditable onBlur={(e) => handleInputChange(null, 'name', e.target.textContent)}>
          {resumeData.name}
        </h1>
        <p contentEditable onBlur={(e) => handleInputChange(null, 'role', e.target.textContent)}>
          {resumeData.role}
        </p>
        <div className="contact-info">
          <span contentEditable onBlur={(e) => handleInputChange(null, 'phone', e.target.textContent)}>
            {resumeData.phone}
          </span>
          <span contentEditable onBlur={(e) => handleInputChange(null, 'email', e.target.textContent)}>
            {resumeData.email}
          </span>
          <span contentEditable onBlur={(e) => handleInputChange(null, 'linkedin', e.target.textContent)}>
            {resumeData.linkedin}
          </span>
          <span contentEditable onBlur={(e) => handleInputChange(null, 'location', e.target.textContent)}>
            {resumeData.location}
          </span>
        </div>
      </div>

      <div className="section">
        <h2>Summary</h2>
        <p contentEditable onBlur={(e) => handleInputChange(null, 'summary', e.target.textContent)}>
          {resumeData.summary}
        </p>
      </div>

      <div className="section">
        <h2>Experience</h2>
        {resumeData.experience.map((exp, index) => (
          <div key={index} className="experience-item">
            <h3 contentEditable onBlur={(e) => handleInputChange('experience', 'company', e.target.textContent, index)}>
              {exp.company}
            </h3>
            <p contentEditable onBlur={(e) => handleInputChange('experience', 'location', e.target.textContent, index)}>
              {exp.location}
            </p>
            <p contentEditable onBlur={(e) => handleInputChange('experience', 'title', e.target.textContent, index)}>
              {exp.title}
            </p>
            <p contentEditable onBlur={(e) => handleInputChange('experience', 'startDate', e.target.textContent, index)}>
              {exp.startDate} - {exp.endDate}
            </p>
            <ul>
              {exp.achievements.map((achievement, i) => (
                <li key={i} contentEditable onBlur={(e) => {
                  const updatedAchievements = [...exp.achievements];
                  updatedAchievements[i] = e.target.textContent;
                  handleInputChange('experience', 'achievements', updatedAchievements, index);
                }}>
                  {achievement}
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>

      <div className="section">
        <h2>Education</h2>
        {resumeData.education.map((edu, index) => (
          <div key={index} className="education-item">
            <h3 contentEditable onBlur={(e) => handleInputChange('education', 'school', e.target.textContent, index)}>
              {edu.school}
            </h3>
            <p contentEditable onBlur={(e) => handleInputChange('education', 'location', e.target.textContent, index)}>
              {edu.location}
            </p>
            <p contentEditable onBlur={(e) => handleInputChange('education', 'degree', e.target.textContent, index)}>
              {edu.degree}
            </p>
            <p contentEditable onBlur={(e) => handleInputChange('education', 'startDate', e.target.textContent, index)}>
              {edu.startDate} - {edu.endDate}
            </p>
          </div>
        ))}
      </div>

      <div className="section">
        <h2>Key Achievements</h2>
        {resumeData.achievements.map((achievement, index) => (
          <div key={index} className="achievement-item">
            <h3 contentEditable onBlur={(e) => handleInputChange('achievements', 'title', e.target.textContent, index)}>
              {achievement.title}
            </h3>
            <p contentEditable onBlur={(e) => handleInputChange('achievements', 'description', e.target.textContent, index)}>
              {achievement.description}
            </p>
          </div>
        ))}
      </div>

      <div className="section">
        <h2>Skills</h2>
        <ul>
          {resumeData.skills.map((skill, index) => (
            <li key={index} contentEditable onBlur={(e) => {
              const updatedSkills = [...resumeData.skills];
              updatedSkills[index] = e.target.textContent;
              setResumeData({ ...resumeData, skills: updatedSkills });
            }}>
              {skill}
            </li>
          ))}
        </ul>
      </div>

      <div className="section">
        <h2>Courses</h2>
        {resumeData.courses.map((course, index) => (
          <div key={index} className="course-item">
            <h3 contentEditable onBlur={(e) => handleInputChange('courses', 'title', e.target.textContent, index)}>
              {course.title}
            </h3>
            <p contentEditable onBlur={(e) => handleInputChange('courses', 'description', e.target.textContent, index)}>
              {course.description}
            </p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default App;
