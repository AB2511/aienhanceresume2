import React from "react";
import "./ResumeTemplate.css"; // Create a CSS file for styling

const ResumeTemplate = ({ resumeData }) => {
  return (
    <div className="resume-container">
      <header className="resume-header">
        <h1>{resumeData.name}</h1>
        <h2>{resumeData.role}</h2>
      </header>

      <section className="resume-section">
        <h3>Experience</h3>
        {resumeData.experience.map((job, index) => (
          <div key={index} className="resume-item">
            <h4>{job.position} - {job.company}</h4>
            <p>{job.duration}</p>
            <p>{job.description}</p>
          </div>
        ))}
      </section>

      <section className="resume-section">
        <h3>Education</h3>
        {resumeData.education.map((edu, index) => (
          <div key={index} className="resume-item">
            <h4>{edu.degree}</h4>
            <p>{edu.institution} - {edu.year}</p>
          </div>
        ))}
      </section>

      <section className="resume-section">
        <h3>Skills</h3>
        <ul>
          {resumeData.skills.map((skill, index) => (
            <li key={index}>{skill}</li>
          ))}
        </ul>
      </section>
    </div>
  );
};

export default ResumeTemplate;

