require("dotenv").config();
const express = require("express");
const cors = require("cors");
const bodyParser = require("body-parser");
const axios = require("axios");
const PDFDocument = require("pdfkit");
const resumeRoutes = require("./routes/resumeRoute");

const app = express();
const PORT = process.env.PORT || 5000;

app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

app.use("/api/resume", resumeRoutes);

// DeepSeek AI Resume Improvement API
app.post("/improve-resume", async (req, res) => {
    try {
        const { resumeText, style, jobRole } = req.body;  // Include job role
        const prompt = `
        Improve this resume in a ${style} tone. Ensure it is ATS-friendly, emphasizes key skills, and is optimized for a ${jobRole} role:
        
        ${resumeText}
        `;

        const response = await axios.post("https://api.deepseek.com/v1/chat/completions", {
            model: "deepseek-chat",
            messages: [
                { role: "system", content: "You are a professional resume writer with expertise in ATS-friendly resumes." },
                { role: "user", content: prompt }
            ],
        }, { headers: { Authorization: `Bearer ${process.env.DEEPSEEK_API_KEY}` } });

        res.json({ improvedResume: response.data.choices[0].message.content });
    } catch (error) {
        console.error("Error calling DeepSeek API:", error);
        res.status(500).json({ error: "AI processing failed" });
    }
});


// Generate Resume PDF
app.post("/generate-pdf", async (req, res) => {
    try {
        const { resumeText } = req.body;
        const doc = new PDFDocument();
        res.setHeader("Content-Disposition", "attachment; filename=resume.pdf");
        res.setHeader("Content-Type", "application/pdf");
        
        doc.pipe(res);
        doc.fontSize(12).text(resumeText, { align: "left" });
        doc.end();
    } catch (error) {
        console.error("Error generating PDF:", error);
        res.status(500).json({ error: "PDF generation failed" });
    }
});


// Start Server
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));

