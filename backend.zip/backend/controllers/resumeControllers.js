require("dotenv").config();
const axios = require("axios");
const Resume = require("../models/Resume.model.js");

// DeepSeek AI API Function
const DeepSeekAI = async (prompt) => {
  try {
    const response = await axios.post(
      "https://api.deepseek.com/v1/chat/completions",
      {
        model: "deepseek-chat",
        messages: [{ role: "user", content: prompt }],
        temperature: 0.6,
        max_tokens: 250,
      },
      {
        headers: {
          Authorization: `Bearer ${process.env.DEEPSEEK_API_KEY}`,
          "Content-Type": "application/json",
        },
      }
    );

    return response.data.choices[0].message.content;
  } catch (error) {
    console.error("DeepSeek AI Error:", error);
    return null;
  }
};

// Resume Creation Controller
const createResume = async (req, res) => {
  try {
    const { fullName, currentPosition, currentLength, currentSkills, workHistory } = req.body;
    const workArray = JSON.parse(workHistory);

    const newEntry = {
      fullName,
      image_url: `http://localhost:5000/uploads/${req.file.filename}`,
      currentPosition,
      currentLength,
      currentSkills,
      workHistory: workArray,
    };

    // AI Prompts
    const prompt1 = `I am writing a resume. My details are:\n- Name: ${fullName}\n- Role: ${currentPosition} (${currentLength} years).\n- Skills: ${currentSkills}\nCan you write a 100-word professional summary for my resume in first-person perspective?`;

    const prompt2 = `I am writing a resume. My details are:\n- Name: ${fullName}\n- Role: ${currentPosition} (${currentLength} years).\n- Skills: ${currentSkills}\nCan you list key points to improve my ATS (Applicant Tracking System) score?`;

    const workDetails = workArray.map((job, index) => `${index + 1}. ${job.name} as a ${job.position}`).join("\n");

    const prompt3 = `I have worked in ${workArray.length} companies:\n${workDetails}\nCan you write 50 words per company about my contributions and achievements in first-person perspective?`;

    // Call DeepSeek AI for Resume Content
    const objective = await DeepSeekAI(prompt1);
    const keypoints = await DeepSeekAI(prompt2);
    const jobResponsibilities = await DeepSeekAI(prompt3);

    const aiGeneratedData = { objective, keypoints, jobResponsibilities };
    const resumeData = { ...newEntry, ...aiGeneratedData };

    // Save to Database
    const resume = new Resume(resumeData);
    await resume.save();

    res.json({ message: "Resume created successfully!", data: resume });
  } catch (error) {
    console.error("Error processing resume request:", error);
    res.status(500).json({ message: "Error processing request", error: error.message });
  }
};

module.exports = { createResume };
